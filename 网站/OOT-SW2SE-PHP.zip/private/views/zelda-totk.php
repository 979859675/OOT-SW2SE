<?php if (!defined('OOT_APP')) { http_response_code(404); exit; } ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
	<title>Savegame Editor &ndash; The legend of Zelda: Tears of the Kingdom</title>
	<meta http-equiv="content-Type" content="text/html; charset=UTF-8"/>
	<meta name="description" content="A savegame editor for The legend of Zelda: Tears of the Kingdom. It can edit: items, weapon durability, modifiers, horses and more!"/>
	<meta name="keywords" content="html5, savegame, save, editor, hack, exploit, switch, zelda, tears of the kingdom, totk, weapon, durability, modifier, horse, epona, korok, unlocker, dlc, amiibo"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"/>
	<link rel="shortcut icon" href="assets/games/zelda-totk/favicon.png"/>
	<link type="text/css" rel="stylesheet" href="assets/games/zelda-totk/zelda-totk.css" media="all"/>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
<link rel="stylesheet" href="assets/games-shell.css"><script src="assets/multi-game.js" defer></script></head>
<body>

<!-- HEADER -->
<div id="header">
	<div class="wrapper">
		<div id="header-top">
			<div class="row padding-vertical">
				<h1>Savegame Editor for The legend of Zelda: TOTK</h1>
				<div class="text-left"><img src="assets/games/zelda-totk/assets/logo.png" style="max-width:90%"/></div>
				<div class="text-right header-buttons">
					by <a href="/" class="author">Marc Robledo</a>
					<a href="https://github.com/marcrobledo/savegame-editors/tree/master/zelda-totk" target="_blank" class="button"><img src="assets/games/zelda-totk/assets/octicons/octicon_github.svg" loading="lazy" class="octicon" /> See on GitHub</a>
					<a href="https://www.paypal.me/marcrobledo/5" target="_blank" rel="nofollow" class="donate button"><img src="assets/games/zelda-totk/assets/octicons/octicon_heart.svg" loading="lazy" class="octicon" /> Donate</a>
				</div>
			</div>
		</div>
		<div id="toolbar" class="hide">
			<div class="row">
				<div id="nav">
					<button class="nav-link" data-translate-title="Home" title="Home" data-target="home"><i class="tab-icon home"></i></button>
					<button class="nav-link" data-translate-title="Weapons" title="Weapons" data-target="weapons"><i class="tab-icon weapons"></i></button>
					<button class="nav-link" data-translate-title="Bows" title="Bows" data-target="bows"><i class="tab-icon bows"></i></button>
					<button class="nav-link" data-translate-title="Shields" title="Shields" data-target="shields"><i class="tab-icon shields"></i></button>
					<button class="nav-link" data-translate-title="Armors" title="Armors" data-target="armors"><i class="tab-icon clothes"></i></button>
					<button class="nav-link" data-translate-title="Materials" title="Materials" data-target="materials"><i class="tab-icon materials"></i></button>
					<button class="nav-link" data-translate-title="Food" title="Food" data-target="food"><i class="tab-icon food"></i></button>
					<button class="nav-link" data-translate-title="Zonai devices" title="Zonai devices" data-target="devices"><i class="tab-icon devices"></i></button>
					<button class="nav-link" data-translate-title="Key items" title="Key items" data-target="key"><i class="tab-icon other"></i></button>
					<button class="nav-link" data-translate-title="Horses" title="Horses" data-target="horses"><i class="tab-icon horses"></i></button>
					<button class="nav-link" data-translate-title="Master editor" title="Master editor" data-target="master"><i class="tab-icon master"></i></button>
				</div>
				<div>
					<button class="btn"><img src="assets/games/zelda-totk/assets/octicons/octicon_x.svg" loading="lazy" class="octicon" /> <span data-translate="Close file">关闭文件</span></button>
					<button class="btn btn-primary"><img src="assets/games/zelda-totk/assets/octicons/octicon_check.svg" loading="lazy" class="octicon" /> <span data-translate="Save changes">保存更改</span></button>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- THE EDITOR -->
<div id="container-startup" class="wrapper">
	<div id="alert-troubleshooting" class="alert alert-info">
		
		<p><strong>Troubleshooting</strong>: Please read the <a href="https://github.com/marcrobledo/savegame-editors/wiki/TOTK-known-issues-&-FAQ" target="_blank">list of known issues</a> if you are having problems when loading/saving your edited savegame.</p>
		<p class="alert-danger"><strong>Always remember to make backups of your savegames before editing. Use this savegame editor at your own risk. By using it, you are responsible of any data lost.</strong></p>		
	</div>
	<div id="container-language" class="text-center">
		<label for="select-language">Select your language</label>
		<select id="select-language">
			<option value="en">English</option>
			<option value="fr">Français</option>
			<option value="fr_alt">Français (Canada)</option>
			<option value="de">Deutsch</option>
			<option value="it">Italiano</option>
			<option value="es">Español</option>
			<option value="es_alt">Español latino</option>
			<option value="nl">Dutch</option>
			<option value="ru">Russian</option>
			<option value="ja">Japanese</option>
			<option value="ko">Korean</option>
			<option value="zh">Chinese (simplified)</option>
			<option value="zh_alt">Chinese (traditional)</option>
		</select>
	</div>
</div>
<div id="the-editor" class="wrapper hide">
	<!-- DEBUG -->
	<div id="debug"></div>
	
	<!-- TAB: HOME -->
	<div id="tab-home">
		<!-- RUPEES -->
		<h3 class="border-red" data-translate="Status">基本数值</h3>
		<div class="row mb-10">
			<div><label data-translate="Game version">游戏版本</label></div>
			<div><span id="span-version"></span></div>
		</div>
		<div class="row mb-10">
			<div><label data-translate="Playtime">游玩时长</label></div>
			<div><span id="span-playtime"></span></div>
		</div>
		<div class="row mb-5">
			<div><label for="number-rupees" data-translate="Rupees">卢比</label></div>
			<div class="col-right"><input id="number-rupees" class="full-width" type="text" /></div>
		</div>
		<div class="row mb-5">
			<div><label for="select-max-hearts" data-translate="Max. hearts">最大心心</label></div>
			<div class="col-right">
				<select id="select-max-hearts" class="full-width">
					<option value="4">1 heart</option>
					<option value="8">2 hearts</option>
					<option value="12">3 hearts</option>
					<option value="16">4 hearts</option>
					<option value="20">5 hearts</option>
					<option value="24">6 hearts</option>
					<option value="28">7 hearts</option>
					<option value="32">8 hearts</option>
					<option value="36">9 hearts</option>
					<option value="40">10 hearts</option>
					<option value="44">11 hearts</option>
					<option value="48">12 hearts</option>
					<option value="52">13 hearts</option>
					<option value="56">14 hearts</option>
					<option value="60">15 hearts</option>
					<option value="64">16 hearts</option>
					<option value="68">17 hearts</option>
					<option value="72">18 hearts</option>
					<option value="76">19 hearts</option>
					<option value="80">20 hearts</option>
					<option value="84">21 hearts</option>
					<option value="88">22 hearts</option>
					<option value="92">23 hearts</option>
					<option value="96">24 hearts</option>
					<option value="100">25 hearts</option>
					<option value="104">26 hearts</option>
					<option value="108">27 hearts</option>
					<option value="112">28 hearts</option>
					<option value="116">29 hearts</option>
					<option value="120">30 hearts</option>
					<option value="124">31 hearts</option>
					<option value="128">32 hearts</option>
					<option value="132">33 hearts</option>
					<option value="136">34 hearts</option>
					<option value="140">35 hearts</option>
					<option value="144">36 hearts</option>
					<option value="148">37 hearts</option>
					<option value="152">38 hearts</option>
					<option value="156">39 hearts</option>
					<option value="160">40 hearts</option>
				</select>
			</div>
		</div>
		<div class="row mb-5">
			<div><label for="select-max-stamina" data-translate="Max. stamina">最大精力</label></div>
			<div class="col-right">
				<select id="select-max-stamina" class="full-width">
					<option value="1148846080">1 wheel</option>
					<option value="1150681088">1 wheel+1/5</option>
					<option value="1152319488">1 wheel+2/5</option>
					<option value="1153957888">1 wheel+3/5</option>
					<option value="1155596288">1 wheel+4/5</option>
					<option value="1157234688">2 wheels</option>
					<option value="1158250496">2 wheels+1/5</option>
					<option value="1159069696">2 wheels+2/5</option>
					<option value="1159888896">2 wheels+3/5</option>
					<option value="1160708096">2 wheels+4/5</option>
					<option value="1161527296">3 wheels</option>
					<option value="1342177279">*Infinite</option>
				</select>
			</div>
		</div>
		<div class="row mb-5">
			<div><label for="select-max-battery" data-translate="Battery size">电池容量</label></div>
			<div class="col-right">
				<select id="select-max-battery" class="full-width">
					<option value="3000">3000</option>
					<option value="4000">4000</option>
					<option value="5000">5000</option>
					<option value="6000">6000</option>
					<option value="7000">7000</option>
					<option value="8000">8000</option>
					<option value="9000">9000</option>
					<option value="10000">10000</option>
					<option value="11000">11000</option>
					<option value="12000">12000</option>
					<option value="13000">13000</option>
					<option value="14000">14000</option>
					<option value="15000">15000</option>
					<option value="16000">16000</option>
					<option value="17000">17000</option>
					<option value="18000">18000</option>
					<option value="19000">19000</option>
					<option value="20000">20000</option>
					<option value="21000">21000</option>
					<option value="22000">22000</option>
					<option value="23000">23000</option>
					<option value="24000">24000</option>
					<option value="25000">25000</option>
					<option value="26000">26000</option>
					<option value="27000">27000</option>
					<option value="28000">28000</option>
					<option value="29000">29000</option>
					<option value="30000">30000</option>
					<option value="31000">31000</option>
					<option value="32000">32000</option>
					<option value="33000">33000</option>
					<option value="34000">34000</option>
					<option value="35000">35000</option>
					<option value="36000">36000</option>
					<option value="37000">37000</option>
					<option value="38000">38000</option>
					<option value="39000">39000</option>
					<option value="40000">40000</option>
					<option value="41000">41000</option>
					<option value="42000">42000</option>
					<option value="43000">43000</option>
					<option value="44000">44000</option>
					<option value="45000">45000</option>
					<option value="46000">46000</option>
					<option value="47000">47000</option>
					<option value="48000">48000</option>
				</select>
			</div>
		</div>
		<div class="row mb-5">
			<div><label for="number-pony-points" data-translate="Pony points">驿站点数</label></div>
			<div class="col-right"><input id="number-pony-points" class="full-width" type="text" /></div>
		</div>
		
		<!-- Pouch size -->
		<h3 class="border-green" data-translate="Pouch size">袋子大小</h3>
		<div class="row mb-5">
			<div><label for="number-pouch-size-swords" data-translate="Sword pouch size">武器袋大小</label></div>
			<div class="col-right"><input id="number-pouch-size-swords" class="full-width" type="text" /></div>
		</div>
		<div class="row mb-5">
			<div><label for="number-pouch-size-bows" data-translate="Bow pouch size">弓箭袋大小</label></div>
			<div class="col-right"><input id="number-pouch-size-bows" class="full-width" type="text" /></div>
		</div>
		<div class="row">
			<div><label for="number-pouch-size-shields" data-translate="Shield pouch size">盾牌袋大小</label></div>
			<div class="col-right"><input id="number-pouch-size-shields" class="full-width" type="text" /></div>
		</div>
	
		<!-- Coordinates -->
		<h3 class="border-orange" data-translate="Link's position">林克位置</h3>
		<div class="row mb-10">
			<div><label for="float-pos-x" data-translate="Coordinates">坐标</label> (XYZ)</div>
			<div class="col-right">
				<input id="float-pos-x" class="medium" type="text" />
				<input id="float-pos-y" class="medium" type="text" />
				<input id="float-pos-z" class="medium" type="text" />
			</div>
		</div>
		<!-- <div class="row">
			<div><label for="map" data-translate="Map">Map</label></div>
			<div class="col-right">
				<select id="map">
					<option value="OpeningField">OpeningField</option>
					<option value="MainField">MainField</option>
					<option value="Dungeon000">Dungeon000</option>
					<option value="Dungeon001">Dungeon001</option>
					<option value="Dungeon002">Dungeon002</option>
					<option value="Dungeon003">Dungeon003</option>
					<option value="Dungeon004">Dungeon004</option>
					<option value="Dungeon005">Dungeon005</option>
					<option value="Dungeon006">Dungeon006</option>
					<option value="Dungeon007">Dungeon007</option>
					<option value="Dungeon008">Dungeon008</option>
					<option value="Dungeon009">Dungeon009</option>
					<option value="Dungeon010">Dungeon010</option>
					<option value="Dungeon011">Dungeon011</option>
					<option value="Dungeon012">Dungeon012</option>
					<option value="Dungeon013">Dungeon013</option>
					<option value="Dungeon014">Dungeon014</option>
					<option value="Dungeon015">Dungeon015</option>
					<option value="Dungeon016">Dungeon016</option>
					<option value="Dungeon017">Dungeon017</option>
					<option value="Dungeon018">Dungeon018</option>
					<option value="Dungeon019">Dungeon019</option>
					<option value="Dungeon020">Dungeon020</option>
					<option value="Dungeon021">Dungeon021</option>
					<option value="Dungeon022">Dungeon022</option>
					<option value="Dungeon023">Dungeon023</option>
					<option value="Dungeon024">Dungeon024</option>
					<option value="Dungeon025">Dungeon025</option>
					<option value="Dungeon026">Dungeon026</option>
					<option value="Dungeon027">Dungeon027</option>
					<option value="Dungeon028">Dungeon028</option>
					<option value="Dungeon029">Dungeon029</option>
					<option value="Dungeon030">Dungeon030</option>
					<option value="Dungeon031">Dungeon031</option>
					<option value="Dungeon032">Dungeon032</option>
					<option value="Dungeon033">Dungeon033</option>
					<option value="Dungeon034">Dungeon034</option>
					<option value="Dungeon035">Dungeon035</option>
					<option value="Dungeon036">Dungeon036</option>
					<option value="Dungeon037">Dungeon037</option>
					<option value="Dungeon038">Dungeon038</option>
					<option value="Dungeon039">Dungeon039</option>
					<option value="Dungeon040">Dungeon040</option>
					<option value="Dungeon041">Dungeon041</option>
					<option value="Dungeon042">Dungeon042</option>
					<option value="Dungeon043">Dungeon043</option>
					<option value="Dungeon044">Dungeon044</option>
					<option value="Dungeon045">Dungeon045</option>
					<option value="Dungeon046">Dungeon046</option>
					<option value="Dungeon047">Dungeon047</option>
					<option value="Dungeon048">Dungeon048</option>
					<option value="Dungeon049">Dungeon049</option>
					<option value="Dungeon050">Dungeon050</option>
					<option value="Dungeon051">Dungeon051</option>
					<option value="Dungeon052">Dungeon052</option>
					<option value="Dungeon053">Dungeon053</option>
					<option value="Dungeon054">Dungeon054</option>
					<option value="Dungeon055">Dungeon055</option>
					<option value="Dungeon056">Dungeon056</option>
					<option value="Dungeon057">Dungeon057</option>
					<option value="Dungeon058">Dungeon058</option>
					<option value="Dungeon059">Dungeon059</option>
					<option value="Dungeon060">Dungeon060</option>
					<option value="Dungeon061">Dungeon061</option>
					<option value="Dungeon062">Dungeon062</option>
					<option value="Dungeon063">Dungeon063</option>
					<option value="Dungeon064">Dungeon064</option>
					<option value="Dungeon065">Dungeon065</option>
					<option value="Dungeon066">Dungeon066</option>
					<option value="Dungeon067">Dungeon067</option>
					<option value="Dungeon068">Dungeon068</option>
					<option value="Dungeon069">Dungeon069</option>
					<option value="Dungeon070">Dungeon070</option>
					<option value="Dungeon071">Dungeon071</option>
					<option value="Dungeon072">Dungeon072</option>
					<option value="Dungeon073">Dungeon073</option>
					<option value="Dungeon074">Dungeon074</option>
					<option value="Dungeon075">Dungeon075</option>
					<option value="Dungeon076">Dungeon076</option>
					<option value="Dungeon077">Dungeon077</option>
					<option value="Dungeon078">Dungeon078</option>
					<option value="Dungeon079">Dungeon079</option>
					<option value="Dungeon080">Dungeon080</option>
					<option value="Dungeon081">Dungeon081</option>
					<option value="Dungeon082">Dungeon082</option>
					<option value="Dungeon083">Dungeon083</option>
					<option value="Dungeon084">Dungeon084</option>
					<option value="Dungeon085">Dungeon085</option>
					<option value="Dungeon086">Dungeon086</option>
					<option value="Dungeon087">Dungeon087</option>
					<option value="Dungeon088">Dungeon088</option>
					<option value="Dungeon089">Dungeon089</option>
					<option value="Dungeon090">Dungeon090</option>
					<option value="Dungeon091">Dungeon091</option>
					<option value="Dungeon092">Dungeon092</option>
					<option value="Dungeon093">Dungeon093</option>
					<option value="Dungeon094">Dungeon094</option>
					<option value="Dungeon095">Dungeon095</option>
					<option value="Dungeon096">Dungeon096</option>
					<option value="Dungeon097">Dungeon097</option>
					<option value="Dungeon098">Dungeon098</option>
					<option value="Dungeon099">Dungeon099</option>
					<option value="Dungeon100">Dungeon100</option>
					<option value="Dungeon101">Dungeon101</option>
					<option value="Dungeon102">Dungeon102</option>
					<option value="Dungeon103">Dungeon103</option>
					<option value="Dungeon104">Dungeon104</option>
					<option value="Dungeon105">Dungeon105</option>
					<option value="Dungeon106">Dungeon106</option>
					<option value="Dungeon107">Dungeon107</option>
					<option value="Dungeon108">Dungeon108</option>
					<option value="Dungeon109">Dungeon109</option>
					<option value="Dungeon110">Dungeon110</option>
					<option value="Dungeon111">Dungeon111</option>
					<option value="Dungeon112">Dungeon112</option>
					<option value="Dungeon113">Dungeon113</option>
					<option value="Dungeon114">Dungeon114</option>
					<option value="Dungeon115">Dungeon115</option>
					<option value="Dungeon116">Dungeon116</option>
					<option value="Dungeon117">Dungeon117</option>
					<option value="Dungeon118">Dungeon118</option>
					<option value="Dungeon119">Dungeon119</option>
					<option value="Dungeon120">Dungeon120</option>
					<option value="Dungeon121">Dungeon121</option>
					<option value="Dungeon122">Dungeon122</option>
					<option value="Dungeon123">Dungeon123</option>
					<option value="Dungeon124">Dungeon124</option>
					<option value="Dungeon125">Dungeon125</option>
					<option value="Dungeon126">Dungeon126</option>
					<option value="Dungeon127">Dungeon127</option>
					<option value="Dungeon128">Dungeon128</option>
					<option value="Dungeon129">Dungeon129</option>
					<option value="Dungeon130">Dungeon130</option>
					<option value="Dungeon131">Dungeon131</option>
					<option value="Dungeon132">Dungeon132</option>
					<option value="Dungeon133">Dungeon133</option>
					<option value="Dungeon134">Dungeon134</option>
					<option value="Dungeon135">Dungeon135</option>
					<option value="Dungeon136">Dungeon136</option>
					<option value="Dungeon137">Dungeon137</option>
					<option value="Dungeon138">Dungeon138</option>
					<option value="Dungeon139">Dungeon139</option>
					<option value="Dungeon140">Dungeon140</option>
					<option value="Dungeon141">Dungeon141</option>
					<option value="Dungeon142">Dungeon142</option>
					<option value="Dungeon143">Dungeon143</option>
					<option value="Dungeon144">Dungeon144</option>
					<option value="Dungeon145">Dungeon145</option>
					<option value="Dungeon146">Dungeon146</option>
					<option value="Dungeon147">Dungeon147</option>
					<option value="Dungeon148">Dungeon148</option>
					<option value="Dungeon149">Dungeon149</option>
					<option value="Dungeon150">Dungeon150</option>
					<option value="Dungeon151">Dungeon151</option>
				</select>
			</div>
		</div> -->
	


		<!-- MAP PINS -->
		<h3 class="border-blue" data-translate="Map pins">地图标记</h3>
		<div class="row mb-10">
			<div>
				<div id="map-pins-edit" class="container-counter clickable">
					<span data-translate="Map pins">地图标记</span><br/>
					<span id="span-pin-counter"></span>
				</div>
			</div>
			<div>
				<button class="btn"><img src="assets/games/zelda-totk/assets/octicons/octicon_pin_slash.svg" loading="lazy" class="octicon" /> <span data-translate="Remove all map pins">移除所有地图标记</span></button>
			</div>
		</div>

		<!-- COMPLETIONISM -->
		<h3 class="border-red" data-translate="Completionism">完成度</h3>
		<div class="mb-10 text-center">
			<span data-translate="Choose completionism mode">选择完成度方式</span>:
			<label class="clickable"><input id="input-radio-completionism-map" type="radio" name="completionism" value="map" /> <span data-translate="Pin to map">在地图上标记</span></label>
			<label class="clickable"><input id="input-radio-completionism-unlock" type="radio" name="completionism" value="unlock" /> <span data-translate="Unlock">解锁</span></label>
		</div>
		<div class="mb-10 text-center">
			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Skyview Towers">鸟望塔</strong></div>
				<div><span data-translate="Found">已发现</span>:<br/><span id="span-towers-found-counter"></span></div>
				<div><span data-translate="Activated">已激活</span>:<br/><span id="span-towers-clear-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as found">全部标记为“已发现”</button> | 
						<button data-translate="Set all as activated">全部标记为"已激活"</button>
					</div>
				</div>
			</div>

			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Shrines">破魔神庙</strong></div>
				<div><span data-translate="Found">已发现</span>:<br/><span id="span-shrines-found-counter"></span></div>
				<div><span data-translate="Cleared">已通过</span>:<br/><span id="span-shrines-clear-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as found">全部标记为“已发现”</button> | 
						<button data-translate="Set all as cleared">全部标记为“已通过”</button>
					</div>
				</div>
			</div>

			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Lightroots">破魔之根</strong></div>
				<div><span data-translate="Found">已发现</span>:<br/><span id="span-lightroots-found-counter"></span></div>
				<div><span data-translate="Activated">已激活</span>:<br/><span id="span-lightroots-clear-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as found">全部标记为“已发现”</button> | 
						<button data-translate="Set all as activated">全部标记为"已激活"</button>
					</div>
				</div>
			</div>
		</div>

		<div class="mb-10 text-center">
			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Koroks">隐藏的克洛格</strong></div>
				<div><span id="span-korok-hidden-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as found">全部标记为“已发现”</button>
					</div>
				</div>
			</div>
			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Strayed koroks">迷路的克洛格</strong> <small>(&times;2)</small></div>
				<div><span id="span-korok-carry-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as carried">全部标记为"已搬运"</button>
					</div>
				</div>
			</div>
			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Bubbuls">魔犹依</strong></div>
				<div><span id="span-bubbuls-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as defeated">全部标记为"已击杀"</button>
					</div>
				</div>
			</div>
		</div>

		<div class="mb-10 text-center">
			<div class="container-counter large">
				<div class="mb-10"><strong data-translate="Locations">探索点</strong></div>
				<div><span id="span-locations-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as visited">全部标记为"已访问"</button>
					</div>
				</div>
			</div>
		</div>

		<div class="mb-10 text-center">
			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Caves">洞穴</strong></div>
				<div><span id="span-location-caves-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as visited">全部标记为"已访问"</button>
					</div>
				</div>
			</div>
			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Wells">井</strong></div>
				<div><span id="span-location-wells-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as visited">全部标记为"已访问"</button>
					</div>
				</div>
			</div>
			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Chasms">深穴</strong></div>
				<div><span id="span-location-chasms-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as visited">全部标记为"已访问"</button>
					</div>
				</div>
			</div>
		</div>

		<div class="mb-10 text-center">
			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Hinox">西诺克斯</strong></div>
				<div><span id="span-boss-hinox-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as defeated">全部标记为"已击杀"</button>
					</div>
				</div>
			</div>
			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Talus">岩石巨人</strong></div>
				<div><span id="span-boss-talus-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as defeated">全部标记为"已击杀"</button>
					</div>
				</div>
			</div>
			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Molduga">莫尔德拉吉克</strong></div>
				<div><span id="span-boss-molduga-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as defeated">全部标记为"已击杀"</button>
					</div>
				</div>
			</div>
		</div>
		<div class="mb-10 text-center">
			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Flux Construct">方块魔像</strong></div>
				<div><span id="span-boss-flux-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as defeated">全部标记为"已击杀"</button>
					</div>
				</div>
			</div>
			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Frox">巨霸迦马</strong></div>
				<div><span id="span-boss-frox-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as defeated">全部标记为"已击杀"</button>
					</div>
				</div>
			</div>
			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Gleeok">古栗欧克</strong></div>
				<div><span id="span-boss-gleeok-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as defeated">全部标记为"已击杀"</button>
					</div>
				</div>
			</div>
		</div>

		<div class="mb-10 text-center">
			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Sage's Wills">贤者的遗志</strong></div>
				<div><span id="span-sage-wills-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as found">全部标记为“已发现”</button>
					</div>
				</div>
			</div>
			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Old maps">残旧的地图</strong></div>
				<div><span id="span-old-maps-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as found">全部标记为“已发现”</button>
					</div>
				</div>
			</div>
			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Addison signposts">卡邦达广告牌</strong></div>
				<div><span id="span-addison-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as cleared">全部标记为“已通过”</button>
					</div>
				</div>
			</div>
		</div>

		<div class="mb-10 text-center">
			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Schema stones">设计图石板</strong></div>
				<div><span id="span-schematics-stone-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as found">全部标记为“已发现”</button>
					</div>
				</div>
			</div>
			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Yiga schematics">依盖队设计图</strong></div>
				<div><span id="span-schematics-yiga-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-map">
						<button data-translate="Pin missing to map">在地图上标记遗漏点</button>
					</div>
					<div class="completionism-actions-unlock">
						<button data-translate="Set all as found">全部标记为“已发现”</button>
					</div>
				</div>
			</div>
		</div>

		<div class="mb-10 text-center">
			<div class="container-counter">
				<div class="mb-10"><strong data-translate="Hyrule Compendium">海拉鲁图鉴</strong></div>
				<div><span id="span-compendium-counter"></span></div>
				<div class="completionism-actions">
					<div class="completionism-actions-unlock">
						<button data-translate="Set current to stock">已激活的图鉴使用官方照片</button> | 
						<button data-translate="Unlock missing">解锁未发现图鉴</button>
					</div>
				</div>
			</div>
		</div>


		<!-- AUTOBUILDER -->
		<h3 class="border-grey" data-translate="Autobuilder">蓝图重现</h3>
		<div class="mb-20">
			<div class="mb-10">
				<label><span data-translate="Blueprint">蓝图</span> <select id="select-autobuilder-index" style="width:auto">
					<option value="0">01</option>
					<option value="1">02</option>
					<option value="2">03</option>
					<option value="3">04</option>
					<option value="4">05</option>
					<option value="5">06</option>
					<option value="6">07</option>
					<option value="7">08</option>
					<option value="8">09</option>
					<option value="9">10</option>
					<option value="10">11</option>
					<option value="11">12</option>
					<option value="12">13</option>
					<option value="13">14</option>
					<option value="14">15</option>
					<option value="15">16</option>
					<option value="16">17</option>
					<option value="17">18</option>
					<option value="18">19</option>
					<option value="19">20</option>
					<option value="20">21</option>
					<option value="21">22</option>
					<option value="22">23</option>
					<option value="23">24</option>
					<option value="24">25</option>
					<option value="25">26</option>
					<option value="26">27</option>
					<option value="27">28</option>
					<option value="28">29</option>
					<option value="29">30</option>
				</select></label>
				<button class="btn" id="button-autobuilder-preview"><img src="assets/games/zelda-totk/assets/octicons/octicon_eye.svg" loading="lazy" class="octicon" /> <span data-translate="Preview">预览</span></button>
				<button class="btn" id="button-autobuilder-export"><img src="assets/games/zelda-totk/assets/octicons/octicon_download.svg" loading="lazy" class="octicon" /> <span data-translate="Export">导出</span></button>
				<button class="btn" id="button-autobuilder-import"><img src="assets/games/zelda-totk/assets/octicons/octicon_upload.svg" loading="lazy" class="octicon" /> <span data-translate="Import">导入</span></button>
				<input id="input-file-autobuilder-import" type="file" accept=".cai" class="hide" />
			</div>
			<div class="text-mute">
				<div class="mb-5" style="font-weight:bold">Share your creations via <img src="assets/games/zelda-totk/assets/octicons/octicon_link_external.svg" loading="lazy" class="octicon" /> <a href="https://www.hyruleworks.com/?content=has_blueprint" target="_blank" class="external-link">HyruleWorks</a> - a community database of builds and blueprints</div>
				<span data-translate="Preview is possible thanks to">Preview is possible thanks to</span> <img src="assets/games/zelda-totk/assets/octicons/octicon_link_external.svg" loading="lazy" class="octicon" /> <a href="http://dev.ssmvc.org:8080/bleh.html" target="_blank" class="external-link">McSpazzy's blueprint viewer/editor</a>
			</div>
		</div>

		<!-- EXPERIENCE -->
		<h3 class="border-grey" data-translate="Experience">履历</h3>
		<div class="text-center mb-10">
			<div id="span-experience-edit" class="container-counter clickable">
				<span data-translate="Total experience">综合履历积分</span><br/>
				<span id="span-experience" style="font-weight:bold"></span>
			</div>
			<div id="pristine-weapons-edit" class="container-counter clickable">
				<span data-translate="Unlocked pristine weapons">已解锁的全新武器</span><br/>
				<span id="span-pristine-weapons-counter"></span>
			</div>
		</div>
		<div class="row mb-10">
			<div style="min-width:144px">
				<strong data-translate="Current enemy tier">己解锁的敌人等级</strong>
			</div>
			<div id="experience-enemy-tiers"></div>
		</div>
		<div class="row mb-10">
			<div style="min-width:144px">
				<strong data-translate="Locked pristine weapons">未解锁的全新武器</strong>
			</div>
			<div id="experience-pristine-weapons"></div>
		</div>
	</div>
	
	<!-- TAB: WEAPONS -->
	<div id="tab-weapons">
		<h3 data-translate="Weapons">武器</h3><div id="container-weapons"></div>
		<div class="text-center">
			<button class="btn" data-translate="Restore decay">修复腐朽</button>
			<button class="btn" data-translate="Restore durability">修复耐久度</button>
			<button class="btn"><img src="assets/games/zelda-totk/assets/octicons/octicon_plus_circle.svg" loading="lazy" class="octicon" /> <span data-translate="Add weapon">增加武器</span></button>
		</div>
	</div>

	<!-- TAB: BOWS -->
	<div id="tab-bows">
		<h3 data-translate="Bows">弓箭</h3><div id="container-bows"></div>
		<div class="text-center">
			<button class="btn" data-translate="Restore durability">修复耐久度</button>
			<button class="btn"><img src="assets/games/zelda-totk/assets/octicons/octicon_plus_circle.svg" loading="lazy" class="octicon" /> <span data-translate="Add bow">增加弓</span></button>
		</div>
		<h3 data-translate="Arrows">箭矢</h3><div id="container-arrows"></div>
		<div class="text-center">
			<button id="button-add-arrows" class="btn"><img src="assets/games/zelda-totk/assets/octicons/octicon_plus_circle.svg" loading="lazy" class="octicon" /> <span data-translate="Add arrows">增加箭矢</span></button>
		</div>
	</div>

	<!-- TAB: SHIELDS -->
	<div id="tab-shields">
		<h3 data-translate="Shields">盾牌</h3><div id="container-shields"></div>
		<div class="text-center">
			<button class="btn" data-translate="Restore durability">修复耐久度</button>
			<button class="btn"><img src="assets/games/zelda-totk/assets/octicons/octicon_plus_circle.svg" loading="lazy" class="octicon" /> <span data-translate="Add shield">增加盾牌</span></button>
		</div>
	</div>

	<!-- TAB: ARMORS -->
	<div id="tab-armors">
		<h3 data-translate="Armors">防具</h3><div id="container-armors"></div>
		<div class="text-center">
			<button class="btn"><span data-translate="Upgrade all">升级全部</span></button>
			<button class="btn"><img src="assets/games/zelda-totk/assets/octicons/octicon_plus_circle.svg" loading="lazy" class="octicon" /> <span data-translate="Add armor">增加防具</span></button>
		</div>
	</div>

	<!-- TAB: MATERIALS -->
	<div id="tab-materials">
		<h3 data-translate="Materials">材料</h3><div id="container-materials"></div>
		<div class="text-center">
			<button class="btn"><img src="assets/games/zelda-totk/assets/octicons/octicon_plus_circle.svg" loading="lazy" class="octicon" /> <span data-translate="Add material">增加材料</span></button>
		</div>
	</div>

	<!-- TAB: FOOD -->
	<div id="tab-food">
		<h3 data-translate="Food">料理</h3><div id="container-food"></div>
		<div class="text-center">
			<button class="btn"><img src="assets/games/zelda-totk/assets/octicons/octicon_plus_circle.svg" loading="lazy" class="octicon" /> <span data-translate="Add food">增加料理</span></button>
		</div>
	</div>

	<!-- TAB: ZONAI DEVICES -->
	<div id="tab-devices">
		<h3 data-translate="Zonai devices">左纳乌装置</h3><div id="container-devices"></div>
		<div class="text-center">
			<button class="btn"><img src="assets/games/zelda-totk/assets/octicons/octicon_plus_circle.svg" loading="lazy" class="octicon" /> <span data-translate="Add zonai device">增加左钠乌装置</span></button>
		</div>
	</div>

	<!-- TAB: KEY -->
	<div id="tab-key">
		<h3 data-translate="Key items">重要物品</h3><div id="key-abilities" class="text-center mb-20">
			<label><input type="checkbox" id="key-abilities-UltraHand" /> <img src="assets/games/zelda-totk/assets/item_icons/key/Obj_UltraHand.png" class="item-icon" loading="lazy"/></label>
			<label><input type="checkbox" id="key-abilities-OneTouchBond" /> <img src="assets/games/zelda-totk/assets/item_icons/key/Obj_OneTouchBond.png" class="item-icon" loading="lazy"/></label>
			<label><input type="checkbox" id="key-abilities-Tooreroof" /> <img src="assets/games/zelda-totk/assets/item_icons/key/Obj_Tooreroof.png" class="item-icon" loading="lazy"/></label>
			<label><input type="checkbox" id="key-abilities-ReverseRecorder" /> <img src="assets/games/zelda-totk/assets/item_icons/key/Obj_ReverseRecorder.png" class="item-icon" loading="lazy"/></label>
			<label><input type="checkbox" id="key-abilities-AutoBuilder" /> <img src="assets/games/zelda-totk/assets/item_icons/key/Obj_AutoBuilder.png" class="item-icon" loading="lazy"/></label>
			<label><input type="checkbox" id="key-abilities-AmiiboItem" /> <img src="assets/games/zelda-totk/assets/item_icons/key/Obj_AmiiboItem.png" class="item-icon" loading="lazy"/></label>
		</div><div id="container-key"></div>
		<div class="text-center">
			<button class="btn"><img src="assets/games/zelda-totk/assets/octicons/octicon_plus_circle.svg" loading="lazy" class="octicon" /> <span data-translate="Add key item">增加重要物品</span></button>
		</div>
	</div>

	<!-- TAB: HORSES -->
	<div id="tab-horses">
		<h3 data-translate="Horses" class="border-blue">马匹</h3>
		<div id="container-horses"></div>
		<!-- <div class="row"><div>Untammed horse</div></div>
		<div class="row" id="row-horse10">
			<div class="three columns end"><select id="select-horse10-type"></select></div>
		</div>
		<div class="row">
			<div class="six columns"><label for="float-pos-x-horse">Current horse coordinates (XYZ)</label></div>
			<div class="col-right"><input id="float-pos-x-horse" class="full-width" type="text" /></div>
			<div class="col-right"><input id="float-pos-y-horse" class="full-width" type="text" /></div>
			<div class="col-right"><input id="float-pos-z-horse" class="full-width" type="text" /></div>
		</div> -->
	</div>

	<!-- TAB: MASTER EDITOR -->
	<div id="tab-master">
		<h3 data-translate="Master editor">大师编辑器</h3>
		<div id="master-editor-loading" class="text-center">Master editor is loading...</div>
		<div id="master-editor-hidden" class="hide">
			<div id="row-hashes-import" style="float:right">
				<span class="text-mute">
					<img src="assets/games/zelda-totk/assets/octicons/octicon_link_external.svg" loading="lazy" class="octicon" /> <a href="https://github.com/marcrobledo/savegame-editors/wiki/TOTK-mods-additional-variables-for-Master-Editor" target="_blank" class="external-link" data-translate="Help">Help</a>
				</span>
				<button class="btn" id="button-hashes-import"><img src="assets/games/zelda-totk/assets/octicons/octicon_upload.svg" loading="lazy" class="octicon" /> <span data-translate="Import mod variables">Import mod variables</span></button>
				<input id="input-file-hashes-import" type="file" accept=".csv" class="hide" />
			</div>
			<div class="mb-20">
				<label><span data-translate="Search">搜索</span> <input id="input-custom-filter" type="text" list="knownHashes" placeholder="Search variables" style="width:400px" /></label>
				<datalist id="knownHashes">
					<option value="DefeatedEnemyNum.* OR EnemyBattleData.*">履历</option>
					<option value="HorseList">马匹</option>
					<option value="AutoBuilder.">蓝图重现</option>
					<option value="OwnedParasailPattern.">Usable paraglider fabrics</option>
					<option value="tower">Hyrule tower activation</option>
					<option value="Dragon_">Dragon coordinates</option>
					<option value="IsAppearKorok.">Korok found</option>
					<option value="KorokCarryProgress.">Korok carried</option>
					<option value="DungeonState.Dungeon">破魔神庙</option>
					<option value="ArrivalPointState.">Lighroots</option>
					<option value="PictureBookData.">Compendium status</option>
					<option value="IsFindTreasureMap.*">Treasure maps</option>
					<option value="event">Quests</option>
					<option value="amiibo">Amiibo</option>
				</datalist>
			</div>

			<table id="table"></table>
			<div class="text-center">
				<label for="select-page"><span data-translate="Page">页数</span>: </label>
				<button id="page-prev">&laquo;</button>
				<select id="select-page" class="small"></select>
				<button id="page-next">&raquo;</button>
			</div>
		</div>
	</div>
</div>

<div id="dialog-caption" class="dialog text-center"></div>
<div id="dialog-savegameindex" class="dialog text-center">
	<h3 data-translate="Select save slot to edit">Select save slot to edit</h3><div id="container-savegameslots"></div>
</div>


<div id="toasts-container"></div>



<ul id="dropdown-item" class="dropdown-menu">
	<li><button id="dropdown-item-button-pristine" class="dropdown-item" type="button"><img src="assets/games/zelda-totk/assets/octicons/octicon_sparkle_fill.svg" loading="lazy" class="octicon invert" /> <span data-translate="Restore decay">修复腐朽</span></button></li>
	<li><button id="dropdown-item-button-durability" class="dropdown-item" type="button"><img src="assets/games/zelda-totk/assets/octicons/octicon_tools.svg" loading="lazy" class="octicon invert" /> <span data-translate="Restore durability">修复耐久度</span></button></li>
	<li><button id="dropdown-item-button-infinite" class="dropdown-item" type="button"><img src="assets/games/zelda-totk/assets/octicons/octicon_infinity.svg" loading="lazy" class="octicon invert" /> <span data-translate="Infinite durability">无限耐久度</span></button></li>
	<li><button id="dropdown-item-button-upgrade" class="dropdown-item" type="button"><img src="assets/games/zelda-totk/assets/octicons/octicon_star_fill.svg" loading="lazy" class="octicon invert" /> <span data-translate="Upgrade">升级</span></button></li>
	<li><button id="dropdown-item-button-duplicate" class="dropdown-item" type="button"><img src="assets/games/zelda-totk/assets/octicons/octicon_copy.svg" loading="lazy" class="octicon invert" /> <span data-translate="Duplicate">复制</span></button></li>
	<li><button id="dropdown-item-button-export" class="dropdown-item" type="button"><img src="assets/games/zelda-totk/assets/octicons/octicon_download.svg" loading="lazy" class="octicon invert" /> <span data-translate="Export">导出</span></button></li>
	<li><button id="dropdown-item-button-import" class="dropdown-item" type="button"><img src="assets/games/zelda-totk/assets/octicons/octicon_upload.svg" loading="lazy" class="octicon invert" /> <span data-translate="Import">导入</span></button></li>
	<li><hr class="dropdown-divider"/></li>
	<li><button id="dropdown-item-button-delete" class="dropdown-item btn-danger" type="button"><img src="assets/games/zelda-totk/assets/octicons/octicon_trash.svg" loading="lazy" class="octicon" /> <span data-translate="Delete">删除</span></button></li>
</ul>


<input id="input-file-pouch-import" type="file" accept=".json" class="hide" />

<dialog id="modal-hash-editor" class="modal">
	<div id="modal-hash-editor-header" class="modal-header"></div>
	<div id="modal-hash-editor-body" class="modal-body"></div>
	<div id="modal-hash-editor-footer" class="modal-footer row">
		<div id="modal-hash-editor-footer-left">
			<button id="button-hash-editor-export" class="btn btn-sm" title="Export" data-translate-title="Export"><img src="assets/games/zelda-totk/assets/octicons/octicon_download.svg" loading="lazy" class="octicon" /></button>
			<button id="button-hash-editor-import" class="btn btn-sm" title="Import" data-translate-title="Import"><img src="assets/games/zelda-totk/assets/octicons/octicon_upload.svg" loading="lazy" class="octicon" /></button>
		</div>
		<div id="modal-hash-editor-footer-right">
		</div>
	</div>
	<input id="input-file-hash-editor-import" type="file" accept=".json" class="hide" />
</dialog>



<dialog id="modal-delete-item" class="modal">
	<div class="modal-body">
		<div class="text-center mb-10" id="modal-delete-item-text"></div>
		<div class="text-center mb-10">
			<label><input id="checkbox-delete-item-warning" type="checkbox" checked /> <span data-translate="Show this warning next time">Show this warning next time</span></label>
		</div>
	</div>
	<div class="modal-footer">
		<div class="text-center">
			<button class="btn btn-sm" data-dismiss="modal" data-translate="Cancel">取消</button>
			<button class="btn btn-sm btn-danger" data-dismiss="modal" id="btn-delete-item-confirm"><img src="assets/games/zelda-totk/assets/octicons/octicon_trash.svg" loading="lazy" class="octicon" /> <span data-translate="Delete">删除</span></button>
		</div>
	</div>
</dialog>


</body>
</html>
