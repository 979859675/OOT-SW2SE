<?php if (!defined('OOT_APP')) { http_response_code(404); exit; } ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
	<title>Savegame Editor &ndash; The legend of Zelda: Breath of the wild</title>
	<meta http-equiv="content-Type" content="text/html; charset=UTF-8"/>
	<meta name="description" content="A savegame editor for The legend of Zelda: Breath of the wild. It can edit: items, weapon durability, modifiers and more!"/>
	<meta name="keywords" content="html5, savegame, save, editor, hack, exploit, wii u, zelda, breath of the wild, botw, weapon, durability, modifier, horse, epona, korok, unlocker, dlc, amiibo"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"/>
	<link rel="shortcut icon" href="assets/games/zelda-botw/favicon.png"/>
	<link type="text/css" rel="stylesheet" href="assets/games/zelda-botw/zelda-botw.css" media="all"/>
	
	
	
	
	
	
	
	
<link rel="stylesheet" href="assets/games-shell.css"><script src="assets/multi-game.js" defer></script></head>
<body>

<!-- HEADER -->
<div id="header">
	<div id="header-top">
		<div class="row wrapper padding-vertical">
			<h1>Savegame Editor for The legend of Zelda: BOTW</h1>
			<div class="six columns text-left"><img src="assets/games/zelda-botw/assets/logo.png" style="max-width:90%"/></div>
			<div class="six columns text-right header-buttons">
				by <a href="/" class="author">Marc Robledo</a>
				<a href="https://github.com/marcrobledo/savegame-editors/tree/master/zelda-botw" target="_blank" class="button"><span class="sprite github"></span> See on GitHub</a>
				<a href="https://www.paypal.me/marcrobledo/5" target="_blank" rel="nofollow" class="donate button"><span class="sprite heart"></span> Donate</a>
			</div>
		</div>
	</div>
	<div id="toolbar" class="hidden padding-vertical">
		<div class="row wrapper">
			<div class="twelve columns text-center">
				<span id="span-version"></span>
				|
				<button id="tab-button-home" title="Home" class="tab-button active"><i class="tab-icon home"></i></button>
				<button id="tab-button-weapons" title="Weapons" class="tab-button"><i class="tab-icon weapons"></i></button>
				<button id="tab-button-bows" title="Bows" class="tab-button"><i class="tab-icon bows"></i></button>
				<button id="tab-button-shields" title="Shields" class="tab-button"><i class="tab-icon shields"></i></button>
				<button id="tab-button-clothes" title="Clothes" class="tab-button"><i class="tab-icon clothes"></i></button>
				<button id="tab-button-materials" title="Materials" class="tab-button"><i class="tab-icon materials"></i></button>
				<button id="tab-button-food" title="Food" class="tab-button"><i class="tab-icon food"></i></button>
				<button id="tab-button-other" title="Other" class="tab-button"><i class="tab-icon other"></i></button>
				<button id="tab-button-horses" title="Horses" class="tab-button"><i class="tab-icon horses"></i></button>
				<button id="tab-button-master" title="Master editor" class="tab-button"><i class="tab-icon master"></i></button>
				| <button class="button with-icon icon3">关闭文件</button>
				<button class="button colored blue with-icon icon9">保存更改</button>
			</div>
		</div>
	</div>
</div>

<!-- THE EDITOR -->
<div id="the-editor" class="wrapper hidden">
	<!-- DEBUG -->
	<div id="debug"></div>
	
	<!-- TAB: HOME -->
	<div id="tab-home">
		<!-- RUPEES -->
		<h3 class="border-red">Stats</h3>
		<div class="row">
			<div class="ten columns"><label for="number-rupees">卢比</label></div>
			<div class="two columns"><input id="number-rupees" class="full-width" type="text" /></div>
		</div>
		<div class="row">
			<div class="ten columns"><label for="number-mons">怪</label></div>
			<div class="two columns"><input id="number-mons" class="full-width" type="text" /></div>
		</div>
		<div class="row">
			<div class="ten columns"><label for="number-relic-gerudo">Gerudo relic remaining uses</label></div>
			<div class="two columns text-right"><input id="number-relic-gerudo" class="small" type="text" /></div>
		</div>
		<div class="row">
			<div class="ten columns"><label for="number-relic-goron">Goron relic remaining uses</label></div>
			<div class="two columns text-right"><input id="number-relic-goron" class="small" type="text" /></div>
		</div>
		<div class="row">
			<div class="ten columns"><label for="number-relic-rito">Rito relic remaining uses</label></div>
			<div class="two columns text-right"><input id="number-relic-rito" class="small" type="text" /></div>
		</div>
		<div class="row" id="row-motorcycle">
			<div class="ten columns"><label for="checkbox-motorcycle">Motorcycle</label></div>
			<div class="two columns text-right"><input id="checkbox-motorcycle" type="checkbox" value="1" /></div>
		</div>
		<div class="row">
			<div class="ten columns"><label for="number-playtime">游玩时长</label></div>
			<div class="two columns"><input type="text" id="number-playtime" class="text-right full-width" disabled /></div>
		</div>
		<div class="row">
			<div class="ten columns"><label for="select-max-hearts">最大心心</label></div>
			<div class="two columns">
				<select id="select-max-hearts" class="full-width">
					<option value="4">1</option>
					<option value="8">2 hearts</option>
					<option value="12">3 hearts</option>
					<option value="16">4 hearts</option>
					<option value="20">5 hearts</option>
					<option value="24">6 hearts</option>
					<option value="28">7 hearts</option>
					<option value="32">8 hearts</option>
					<option value="36">9 hearts</option>
					<option value="40">10 hearts</option>
					<option value="44">11 hearts</option>
					<option value="48">12 hearts</option>
					<option value="52">13 hearts</option>
					<option value="56">14 hearts</option>
					<option value="60">15 hearts</option>
					<option value="64">16 hearts</option>
					<option value="68">17 hearts</option>
					<option value="72">18 hearts</option>
					<option value="76">19 hearts</option>
					<option value="80">20 hearts</option>
					<option value="84">21 hearts</option>
					<option value="88">22 hearts</option>
					<option value="92">23 hearts</option>
					<option value="96">24 hearts</option>
					<option value="100">25 hearts</option>
					<option value="104">26 hearts</option>
					<option value="108">27 hearts</option>
					<option value="112">28 hearts</option>
					<option value="116">29 hearts</option>
					<option value="120">30 hearts</option>
				</select>
			</div>
		</div>
		<div class="row">
			<div class="ten columns"><label for="select-max-stamina">最大精力 </label></div>
			<div class="two columns">
				<select id="select-max-stamina" class="full-width">
					<option value="1148846080">1 wheel</option>
					<option value="1150681088">1 wheel+1/5</option>
					<option value="1152319488">1 wheel+2/5</option>
					<option value="1153957888">1 wheel+3/5</option>
					<option value="1155596288">1 wheel+4/5</option>
					<option value="1157234688">2 wheels</option>
					<option value="1158250496">2 wheels+1/5</option>
					<option value="1159069696">2 wheels+2/5</option>
					<option value="1159888896">2 wheels+3/5</option>
					<option value="1160708096">2 wheels+4/5</option>
					<option value="1161527296">3 wheels</option>
				</select>
			</div>
		</div>
		<div class="row" style="margin-top:10px">
			<div class="ten columns">Scale score</div>
			<div class="two columns text-right">
				<span id="span-scale-score"></span>
				<a target="_blank" href="https://www.reddit.com/r/Breath_of_the_Wild/comments/8fchiq/about_difficulty_scaling_for_enemies_and_weapons/" class="external-link-help help">?</a>
			</div>
		</div>
		
		<!-- Coordinates (Requires a memory editor) -->
		<h3 class="border-green">坐标</h3>
		<div class="row">
			<div class="six columns"><label for="float-pos-x">Current Link coordinates (XYZ)</label></div>
			<div class="two columns"><input id="float-pos-x" class="full-width" type="text" /></div>
			<div class="two columns"><input id="float-pos-y" class="full-width" type="text" /></div>
			<div class="two columns"><input id="float-pos-z" class="full-width" type="text" /></div>
		</div>

		<div class="row">
			<div class="six columns"><label for="select-pos-maptype">Map</label></div>
			<div class="three columns"><select id="select-pos-maptype"></select></div>
			<div class="three columns"><select id="select-pos-map"></select></div>
		</div>


	
	


		<!-- COMPLETIONISM -->
		<h3 class="border-blue">完成度</h3>
		<div class="row">
			<div class="seven columns"><label for="number-koroks">Korok seeds</label></div>
			<div class="five columns text-right">
				<input type="text" id="number-koroks" style="width:50px" disabled />
				<button>Get all</button>
				<button>Add pins to Map</button>
			</div>
		</div>

		<div class="row">
			<div class="seven columns"><label for="number-defeated-hinox">Defeated Hinox</label></div>
			<div class="five columns text-right">
				<input type="text" id="number-defeated-hinox" style="width:50px" disabled />
				<button>Defeat all</button>
				<button>Add pins to Map</button>
			</div>
		</div>
		<div class="row">
			<div class="seven columns"><label for="number-defeated-talus">Defeated Talus</label></div>
			<div class="five columns text-right">
				<input type="text" id="number-defeated-talus" style="width:50px" disabled />
				<button>Defeat all</button>
				<button>Add pins to Map</button>
			</div>
		</div>
		<div class="row">
			<div class="seven columns"><label for="number-defeated-molduga">Defeated Molduga</label></div>
			<div class="five columns text-right">
				<input type="text" id="number-defeated-molduga" style="width:50px" disabled />
				<button>Defeat all</button>
				<button>Add pins to Map</button>
			</div>
		</div>
		<div class="row">
			<div class="nine columns"><label for="number-defeated-molduga">海拉鲁图鉴</label></div>
			<div class="three columns text-right">
				<button>Set to stock</button>
			</div>
		</div>

		<div class="row">
			<div class="seven columns">Visited locations</div>
			<div class="five columns text-right">
				<button>Visit all</button>
				<button>Add pins to Map</button>
			</div>
		</div>

		<div class="row">
			<div class="nine columns">Map Pins</div>
			<div class="three columns text-right">
				<input type="text" id="number-map-pins" style="width:50px" disabled />
				<button>Clear</button>
			</div>
		</div>
	</div>
	
	<!-- TAB: WEAPONS -->
	<div id="tab-weapons">
		<h3>武器</h3><div id="container-weapons"></div>
	</div>

	<!-- TAB: BOWS -->
	<div id="tab-bows">
		<h3>弓箭</h3><div id="container-bows"></div>
	</div>

	<!-- TAB: SHIELDS -->
	<div id="tab-shields">
		<h3>盾牌</h3><div id="container-shields"></div>
	</div>

	<!-- TAB: CLOTHES -->
	<div id="tab-clothes">
		<h3>Clothes</h3><div id="container-clothes"></div>
	</div>

	<!-- TAB: MATERIALS -->
	<div id="tab-materials">
		<h3>材料</h3><div id="container-materials"></div>
	</div>

	<!-- TAB: FOOD -->
	<div id="tab-food">
		<h3>料理</h3><div id="container-food"></div>
	</div>

	<!-- TAB: OTHER -->
	<div id="tab-other">
		<h3>Other</h3><div id="container-other"></div>
	</div>

	<!-- ADD ITEM BUTTON -->
	<div id="add-item-button" class="text-center">
		<button class="with-icon icon1">Add item</button>
	</div>
	<!-- TAB: HORSES -->
	<div id="tab-horses">
		<h3 class="border-blue">马匹</h3>
		<div class="row"><div class="twelve columns">Horse #1</div></div>
		<div class="row" id="row-horse0">
			<div class="three columns"><select id="select-horse0-type"></select></div>
			<div class="three columns"><input type="text" id="input-horse0-name" /></div>
			<div class="three columns"><select id="select-horse0-saddles"></select></div>
			<div class="three columns"><select id="select-horse0-reins"></select></div>
		</div>
		<div class="row"><div class="twelve columns">Horse #2</div></div>
		<div class="row" id="row-horse1">
			<div class="three columns"><select id="select-horse1-type"></select></div>
			<div class="three columns"><input type="text" id="input-horse1-name" /></div>
			<div class="three columns"><select id="select-horse1-saddles"></select></div>
			<div class="three columns"><select id="select-horse1-reins"></select></div>
		</div>
		<div class="row"><div class="twelve columns">Horse #3</div></div>
		<div class="row" id="row-horse2">
			<div class="three columns"><select id="select-horse2-type"></select></div>
			<div class="three columns"><input type="text" id="input-horse2-name" /></div>
			<div class="three columns"><select id="select-horse2-saddles"></select></div>
			<div class="three columns"><select id="select-horse2-reins"></select></div>
		</div>
		<div class="row"><div class="twelve columns">Horse #4</div></div>
		<div class="row" id="row-horse3">
			<div class="three columns"><select id="select-horse3-type"></select></div>
			<div class="three columns"><input type="text" id="input-horse3-name" /></div>
			<div class="three columns"><select id="select-horse3-saddles"></select></div>
			<div class="three columns"><select id="select-horse3-reins"></select></div>
		</div>
		<div class="row"><div class="twelve columns">Horse #5</div></div>
		<div class="row" id="row-horse4">
			<div class="three columns"><select id="select-horse4-type"></select></div>
			<div class="three columns"><input type="text" id="input-horse4-name" /></div>
			<div class="three columns"><select id="select-horse4-saddles"></select></div>
			<div class="three columns"><select id="select-horse4-reins"></select></div>
		</div>
		<div class="row"><div class="twelve columns">Untammed horse</div></div>
		<div class="row" id="row-horse5">
			<div class="three columns end"><select id="select-horse5-type"></select></div>
		</div>
		<div class="row">
			<div class="six columns"><label for="float-pos-x-horse">Current horse coordinates (XYZ)</label></div>
			<div class="two columns"><input id="float-pos-x-horse" class="full-width" type="text" /></div>
			<div class="two columns"><input id="float-pos-y-horse" class="full-width" type="text" /></div>
			<div class="two columns"><input id="float-pos-z-horse" class="full-width" type="text" /></div>
		</div>
	</div>

	<!-- TAB: MASTER EDITOR -->
	<div id="tab-master">
		<div id="master-editor-loading" class="text-center">Master editor is loading...</div>
		<div id="master-editor-hidden" class="hidden">
			<label for="select-filters">Filter: </label>
			<select id="select-filters">
				<option value="">- All -</option>
				<option value="WolfLink_|Amiibo">Amiibo</option>
				<option value="_DispNameFlag$">Display flag names</option>
				<option value="100enemy">DLC1</option>
				<option value="Motorcycle">DLC2</option>
				<option value="Horse_">马匹</option>
				<option value="Defeat_Enemy_|Defeated.+Num">Defeated enemies</option>
				<option value="Porch|Cook">道具</option>
				<option value="IsGet_">Get flags</option>
				<option value="HiddenKorok|OldKorok_">Korok</option>
				<option value="^Location_">Visited locations</option>
				<option value="AlbumPicture|PictureBook">Compendium</option>
			</select>
			<input id="input-custom-filter" type="text" placeholder="Search hash keys" />
			
			 | <label for="select-page">Page: </label>
			<button id="page-prev">&laquo;</button>
			<select id="select-page" class="small"></select>
			<button id="page-next">&raquo;</button>


			<table id="table"></table>
		</div>
	</div>	
</div>


</body>
</html>
